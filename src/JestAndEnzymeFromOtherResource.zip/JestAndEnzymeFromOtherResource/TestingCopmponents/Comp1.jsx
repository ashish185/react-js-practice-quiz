import React from 'react';

const Comp1 = () => {
    return (
        <div>
            Comp1
        </div>
    );
};

export default Comp1;