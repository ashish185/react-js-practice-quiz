import React,{Component} from 'react';

/* const Counter = () => {
    const [count, setCount] = useState(2);
    return (
        <div data-test="counter-component-test">
            <h1 data-test="counter-display">The Counter is currently</h1>
            <button data-test="increment-button">Increment Counter</button>
        </div>
    );
};
 */

class Counter extends Component {
    constructor(props){
        super(props);
        this.state={
            count: 2
        }
    }
    handleClick =()=>{
        this.setState((prevState)=>{
            return{
                ...prevState,
                count: prevState.count+1
            }
        })
    }

    render() {
        return (
            <div data-test="counter-component-test">
                <h1 data-test="counter-display">The Counter is currently</h1>
                <button data-test="increment-button" onClick={()=>{this.handleClick()}}
                >Increment Counter</button>
            </div>
        );
    }
}

export default Counter;