import EnzymeAdapter from "enzyme-adapter-react-16";
import Enzyme, { shallow } from 'enzyme';
import Comp1 from "../TestingCopmponents/Comp1";
import Counter from "../TestingCopmponents/CounterComp/Counter";

Enzyme.configure({
    adapter: new EnzymeAdapter()
});
test('Renders Component without error',() =>{
    const myCounterCompRendered= shallow(<Counter/>);
    //matches the given selector
    const foundAttribute=myCounterCompRendered.find("[data-test='counter-component-test']")
    console.debug(foundAttribute);
    expect(foundAttribute.length).toBe(1);
});

test('Renders Counter display',() =>{
    const myCounterCompRendered= shallow(<Counter/>);
    //matches the given selector
    const foundAttribute=myCounterCompRendered.find("[data-test='counter-display']")
    expect(foundAttribute.length).toBe(1);
});
test('Renders Incremented button',() =>{
    const myCounterCompRendered= shallow(<Counter/>);
    //matches the given selector
    const foundAttribute=myCounterCompRendered.find("[data-test='increment-button']")
    expect(foundAttribute.length).toBe(1);
});
test('Comparing State',() =>{
    const myCounterCompRendered= shallow(<Counter/>);
    // ShallowWrapper::state() can only be called on class components
    const initalStateOfCounter=myCounterCompRendered.state('count');
    expect(initalStateOfCounter).toEqual(2);
});

test('Testing handle Click and State',() =>{
    const myCounterCompRendered= shallow(<Counter/>);
    // ShallowWrapper::state() can only be called on class components
    const foundButton=myCounterCompRendered.find("[data-test='increment-button']")
    foundButton.simulate('click');
    myCounterCompRendered.update();
    const countVal =myCounterCompRendered.state('count');
    expect(countVal).toEqual(3);
});